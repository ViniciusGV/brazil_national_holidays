from setuptools import setup
setup(
    name='brazil_national_holidays',
    version='1.0.0',
    description='Manipulates dates based on country holidays',
    author='Vinícius Gomes Vieira',
    packages=['brazil_national_holidays'],
    zip_safe=False
)